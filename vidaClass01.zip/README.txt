Só não fiz o contador porque eu não sei de onde esse dados vem, se ele não vier do backend e você não conseguir fazer me avisa que eu faço por aqui.

Lembrar de revisar todos os links, os da redes sociais eu nem coloquei no footer.